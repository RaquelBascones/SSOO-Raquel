package Escritorio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginScreen {
	
    // Definir las credenciales correctas
    private static final String correct_user= "Raquel";
    private static final String correct_password = "hola";
    

    public static void main(String[] args) {
        // Crear el frame de inicio de sesión
        JFrame loginFrame = new JFrame("Login");
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setSize(800, 600);
        loginFrame.getContentPane().setBackground(Color.BLACK);
        loginFrame.setLayout(new BorderLayout());

        // Crear el panel de login centrado
        JPanel loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBackground(Color.BLACK);
        loginPanel.setPreferredSize(new Dimension(400, 200));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        // Crear los componentes de la pantalla de inicio de sesión
        JLabel userLabel = new JLabel("Usuario");
        userLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 0;
        loginPanel.add(userLabel, gbc);

        JTextField userTextField = new JTextField();
        userTextField.setPreferredSize(new Dimension(200, 25)); // Ajustar el tamaño del campo de texto
        gbc.gridx = 1;
        gbc.gridy = 0;
        loginPanel.add(userTextField, gbc);

        JLabel passwordLabel = new JLabel("Contraseña");
        passwordLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 1;
        loginPanel.add(passwordLabel, gbc);

        JPasswordField passwordField = new JPasswordField();
        passwordField.setPreferredSize(new Dimension(200, 25)); // Ajustar el tamaño del campo de texto
        gbc.gridx = 1;
        gbc.gridy = 1;
        loginPanel.add(passwordField, gbc);

        JLabel confirmPasswordLabel = new JLabel("Ingrese contraseña nuevamente");
        confirmPasswordLabel.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 2;
        loginPanel.add(confirmPasswordLabel, gbc);

        JPasswordField confirmPasswordField = new JPasswordField();
        confirmPasswordField.setPreferredSize(new Dimension(200, 25)); // Ajustar el tamaño del campo de texto
        gbc.gridx = 1;
        gbc.gridy = 2;
        loginPanel.add(confirmPasswordField, gbc);

        // Botón azul para la validación de credenciales
        JButton loginButton = new JButton(new ImageIcon(new ImageIcon("C:\\Users\\raque\\Desktop\\imagenes ssoo\\siguiente-boton.jpg").getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH))); // Cambia esta ruta a tu icono azul
        loginButton.setContentAreaFilled(false);
        loginButton.setBorderPainted(false);
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        loginPanel.add(loginButton, gbc);

        // Añadir el panel de login al centro del frame
        loginFrame.add(loginPanel, BorderLayout.CENTER);

        // Crear el panel inferior para la imagen y el botón de encendido
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setOpaque(false);

        // Crear el panel para la esquina inferior izquierda
        JPanel bottomLeftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomLeftPanel.setOpaque(false);

        // Crear la etiqueta para la imagen (debes tener una imagen en tu proyecto)
        JLabel imageLabel = new JLabel(new ImageIcon(new ImageIcon("path/to/your/image.png").getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH))); // Cambia esta ruta a tu imagen

        // Crear el botón de encendido
        JButton powerButton = new JButton(new ImageIcon(new ImageIcon("C:\\Users\\raque\\Desktop\\imagenes ssoo\\encendido-apagado.jpg").getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH))); // Cambia esta ruta a tu icono de encendido
        powerButton.setContentAreaFilled(false);
        powerButton.setBorderPainted(false);
        powerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int response = JOptionPane.showConfirmDialog(null, "¿Deseas apagar el equipo?", "Confirmar Apagado", JOptionPane.YES_NO_OPTION);
                if (response == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });

        // Añadir la imagen y el botón de encendido al panel inferior izquierdo
        bottomLeftPanel.add(imageLabel);
        bottomLeftPanel.add(powerButton);

        // Añadir el panel inferior izquierdo al panel inferior
        bottomPanel.add(bottomLeftPanel, BorderLayout.WEST);

        // Añadir el panel inferior al frame
        loginFrame.add(bottomPanel, BorderLayout.SOUTH);
        
        
        // Acción del botón de login
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = userTextField.getText();
                String password = new String(passwordField.getPassword());
                String confirmPassword = new String(confirmPasswordField.getPassword());

                if (username.equals(correct_user) && password.equals(correct_password) && password.equals(confirmPassword)) {
                    JOptionPane.showMessageDialog(null, "Se registraron los datos correctamente");
                    loginFrame.dispose(); // Cerrar la pantalla de login
                    DesktopScreen.showDesktop(); // Mostrar el escritorio
                } else if (!username.equals(correct_user) || !password.equals(correct_password)) {
                    JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos. Por favor, inténtelo de nuevo.");
                } else {
                    JOptionPane.showMessageDialog(null, "Las contraseñas no coinciden. Por favor, inténtelo de nuevo.");
                }
            }
        });

        // Mostrar la pantalla de login
        loginFrame.setVisible(true);
    }
}

