package Escritorio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EventDialog extends JDialog {

    private boolean confirmed = false;
    private JTextField eventNameField;
    private JComboBox<String> dayComboBox;
    private JComboBox<Integer> startHourComboBox;
    private JComboBox<Integer> endHourComboBox;
    private JComboBox<Color> colorComboBox;

    public EventDialog(JFrame parent) {
        super(parent, "Añadir Evento", true);
        setSize(300, 200);
        setLayout(new GridLayout(6, 2));

        eventNameField = new JTextField();
        dayComboBox = new JComboBox<>(new String[]{"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"});
        startHourComboBox = new JComboBox<>(getHours());
        endHourComboBox = new JComboBox<>(getHours());
        colorComboBox = new JComboBox<>(new Color[]{Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW, Color.ORANGE, Color.PINK});

        add(new JLabel("Nombre del Evento:"));
        add(eventNameField);
        add(new JLabel("Día:"));
        add(dayComboBox);
        add(new JLabel("Hora de Inicio:"));
        add(startHourComboBox);
        add(new JLabel("Hora de Fin:"));
        add(endHourComboBox);
        add(new JLabel("Color:"));
        add(colorComboBox);

        JButton confirmButton = new JButton("Confirmar");
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                confirmed = true;
                setVisible(false);
            }
        });

        JButton cancelButton = new JButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                confirmed = false;
                setVisible(false);
            }
        });

        add(confirmButton);
        add(cancelButton);
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public String getEventName() {
        return eventNameField.getText();
    }

    public String getDay() {
        return (String) dayComboBox.getSelectedItem();
    }

    public int getStartHour() {
        return (int) startHourComboBox.getSelectedItem();
    }

    public int getEndHour() {
        return (int) endHourComboBox.getSelectedItem();
    }

    public Color getColor() {
        return (Color) colorComboBox.getSelectedItem();
    }

    private Integer[] getHours() {
        Integer[] hours = new Integer[24];
        for (int i = 0; i < 24; i++) {
            hours[i] = i;
        }
        return hours;
    }
}

