package Escritorio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public class CustomTerminal extends JFrame implements ActionListener {
    private JTextArea textArea;
    private JTextField textField;
    private Map<String, Command> commands;
    private Map<String, Color> colorMap;

    public CustomTerminal() {
        // Configuración de la ventana principal
        setTitle("Custom Terminal");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cambiado a DISPOSE_ON_CLOSE
        setLocationRelativeTo(null);

        // Área de texto para la salida de comandos
        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        textArea.setBackground(Color.BLACK);
        textArea.setForeground(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(textArea);

        // Campo de texto para la entrada de comandos
        textField = new JTextField();
        textField.addActionListener(this);
        textField.setBackground(Color.BLACK);
        textField.setForeground(Color.WHITE);

        // Añadir componentes a la ventana
        add(scrollPane, BorderLayout.CENTER);
        add(textField, BorderLayout.SOUTH);

        // Inicializar el manejador de comandos
        commands = new HashMap<>();
        registerCommand("echo", args -> String.join(" ", args));
        registerCommand("date", args -> {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            return formatter.format(new Date());
        });
        registerCommand("galletas", args -> "¡Las galletas son deliciosas!");
        registerCommand("colacao", args -> "Nada mejor que un buen vaso de Colacao por la mañana.");
        registerCommand("chocolate", args -> "El chocolate es un placer delicioso.");
        registerCommand("random", args -> String.valueOf(new Random().nextInt()));
        registerCommand("uuid", args -> UUID.randomUUID().toString());
        registerCommand("flip", args -> new Random().nextBoolean() ? "Heads" : "Tails");
        registerCommand("dice", args -> String.valueOf(new Random().nextInt(6) + 1));
        registerCommand("weather", args -> "Today's weather is sunny with a chance of rainbows.");
        registerCommand("password", args -> generateRandomPassword(12));
        registerCommand("setbg", this::setTerminalBackgroundColor);
        registerCommand("setfg", this::setTerminalForegroundColor);

        // Inicializar el mapa de colores
        initializeColorMap();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String input = textField.getText();
        textArea.append("> " + input + "\n");
        String[] parts = input.split(" ");
        String commandName = parts[0];
        String[] args = new String[parts.length - 1];
        System.arraycopy(parts, 1, args, 0, args.length);

        Command command = commands.get(commandName);
        if (command != null) {
            String output = command.execute(args);
            textArea.append(output + "\n");
        } else {
            textArea.append("Unknown command: " + commandName + "\n");
        }
        textField.setText("");
    }

    private void registerCommand(String name, Command command) {
        commands.put(name, command);
    }

    private String generateRandomPassword(int length) {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_+=<>?";
        Random random = new Random();
        StringBuilder password = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            password.append(chars.charAt(random.nextInt(chars.length())));
        }
        return password.toString();
    }

    private void initializeColorMap() {
        colorMap = new HashMap<>();
        colorMap.put("black", Color.BLACK);
        colorMap.put("white", Color.WHITE);
        colorMap.put("red", Color.RED);
        colorMap.put("green", Color.GREEN);
        colorMap.put("blue", Color.BLUE);
        colorMap.put("yellow", Color.YELLOW);
        colorMap.put("pink", Color.PINK);
        colorMap.put("orange", Color.ORANGE);
        colorMap.put("gray", Color.GRAY);
    }

    private String setTerminalBackgroundColor(String[] args) {
        if (args.length != 1) return "Usage: setbg <color>";
        Color color = colorMap.get(args[0].toLowerCase());
        if (color != null) {
            textArea.setBackground(color);
            textField.setBackground(color);
            return "Background color changed to " + args[0];
        } else {
            return "Unknown color: " + args[0];
        }
    }

    private String setTerminalForegroundColor(String[] args) {
        if (args.length != 1) return "Usage: setfg <color>";
        Color color = colorMap.get(args[0].toLowerCase());
        if (color != null) {
            textArea.setForeground(color);
            textField.setForeground(color);
            return "Foreground color changed to " + args[0];
        } else {
            return "Unknown color: " + args[0];
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CustomTerminal().setVisible(true));
    }

    // Interfaz funcional para los comandos
    @FunctionalInterface
    interface Command {
        String execute(String[] args);
    }
}



