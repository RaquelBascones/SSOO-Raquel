package Escritorio;

import javax.swing.*;
import java.awt.*;

public class WordApp {

    public static void showWord() {
        JFrame wordFrame = new JFrame("Word");
        wordFrame.setSize(800, 600);
        wordFrame.setLayout(new BorderLayout());

        JTextArea wordArea = new JTextArea();
        wordArea.setText("Aquí puedes escribir tus documentos estilo Word.");

        wordFrame.add(new JScrollPane(wordArea), BorderLayout.CENTER);

        wordFrame.setVisible(true);
    }
}
