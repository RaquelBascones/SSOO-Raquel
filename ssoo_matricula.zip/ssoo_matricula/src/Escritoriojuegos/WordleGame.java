package Escritoriojuegos;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class WordleGame extends JFrame {
    private static final int WORD_LENGTH = 5;
    private static final int MAX_ATTEMPTS = 6;
    private String[] wordList = { "WHICH", "THERE", "THEIR", "ABOUT", "WOULD", "THESE", "OTHER", "WORDS", "COULD", "WRITE",
            "FIRST", "WATER", "AFTER", "WHERE", "RIGHT", "THINK", "THREE", "YEARS", "PLACE", "SOUND", "GREAT",
            "AGAIN", "STILL", "EVERY", "SMALL", "FOUND", "THOSE", "NEVER", "UNDER", "MIGHT", "WHILE", "HOUSE",
            "WORLD", "BELOW", "ASKED", "GOING", "LARGE", "UNTIL", "ALONG", "SHALL", "BEING", "OFTEN", "EARTH",
            "BEGAN", "SINCE", "STUDY", "NIGHT", "LIGHT", "ABOVE", "PAPER", "PARTS", "YOUNG", "STORY", "POINT",
            "TIMES", "HEARD", "WHOLE", "WHITE", "GIVEN", "MEANS", "MUSIC", "MILES", "THING", "TODAY", "LATER",
            "USING", "MONEY", "LINES", "ORDER", "GROUP", "AMONG", "LEARN", "KNOWN", "SPACE", "TABLE", "EARLY",
            "TREES", "SHORT", "HANDS", "STATE", "BLACK", "SHOWN", "STOOD", "FRONT", "VOICE", "KINDS", "MAKES",
            "COMES", "CLOSE", "POWER", "LIVED", "VOWEL", "TAKEN", "BUILT", "HEART", "READY", "QUITE", "CLASS",
            "BRING", "ROUND", "HORSE", "SHOWS", "PIECE", "GREEN", "STAND", "BIRDS", "START", "RIVER", "TRIED",
            "LEAST", "FIELD", "WHOSE", "GIRLS", "LEAVE", "ADDED", "COLOR", "THIRD", "HOURS", "MOVED", "PLANT",
            "DOING", "NAMES", "FORMS", "HEAVY", "IDEAS", "CRIED", "CHECK", "FLOOR", "BEGIN", "WOMAN", "ALONE",
            "PLANE", "SPELL", "WATCH", "CARRY", "WROTE", "CLEAR", "NAMED", "BOOKS", "CHILD", "GLASS", "HUMAN",
            "TAKES", "PARTY", "BUILD", "SEEMS", "BLOOD", "SIDES", "SEVEN", "MOUTH", "SOLVE", "NORTH", "VALUE",
            "DEATH", "MAYBE", "HAPPY", "TELLS", "GIVES", "LOOKS", "SHAPE", "LIVES", "STEPS", "AREAS", "SENSE",
            "SPEAK", "FORCE", "OCEAN", "SPEED", "WOMEN", "METAL", "SOUTH", "GRASS", "SCALE", "CELLS", "LOWER",
            "SLEEP", "WRONG", "PAGES", "SHIPS", "NEEDS", "ROCKS", "EIGHT", "MAJOR", "LEVEL", "TOTAL", "AHEAD",
            "REACH", "STARS", "STORE", "SIGHT", "TERMS", "CATCH", "WORKS", "BOARD", "COVER", "SONGS", "EQUAL",
            "STONE", "WAVES", "GUESS", "DANCE", "SPOKE", "BREAK", "CAUSE", "RADIO", "WEEKS", "LANDS", "BASIC",
            "LIKED", "TRADE", "FRESH", "FINAL", "FIGHT", "MEANT", "DRIVE", "SPENT", "LOCAL", "WAXES", "KNOWS",
            "TRAIN", "BREAD", "HOMES", "TEETH", "COAST", "THICK", "BROWN", "CLEAN", "QUIET", "SUGAR", "FACTS",
            "STEEL", "FORTH", "RULES", "NOTES", "UNITS", "PEACE", "MONTH", "VERBS", "SEEDS", "HELPS", "SHARP",
            "VISIT", "WOODS", "CHIEF", "WALLS", "CROSS", "WINGS", "GROWN", "CASES", "FOODS", "CROPS", "FRUIT",
            "STICK", "WANTS", "STAGE", "SHEEP", "NOUNS", "PLAIN", "DRINK", "BONES", "APART", "TURNS", "MOVES",
            "TOUCH", "ANGLE", "BASED", "RANGE", "MARKS", "TIRED", "OLDER", "FARMS", "SPEND", "SHOES", "GOODS",
            "CHAIR", "TWICE", "CENTS", "EMPTY", "ALIKE", "STYLE", "BROKE", "PAIRS", "COUNT", "ENJOY", "SCORE",
            "SHORE", "ROOTS", "PAINT", "HEADS", "SHOOK", "SERVE", "ANGRY", "CROWD", "WHEEL", "QUICK", "DRESS",
            "SHARE", "ALIVE", "NOISE", "SOLID", "CLOTH", "SIGNS", "HILLS", "TYPES", "DRAWN", "WORTH", "TRUCK",
            "PIANO", "UPPER", "LOVED", "USUAL", "FACES", "DROVE", "CABIN", "BOATS", "TOWNS", "PROUD", "COURT",
            "MODEL", "PRIME", "FIFTY", "PLANS", "YARDS", "PROVE", "TOOLS", "PRICE", "SHEET", "SMELL", "BOXES",
            "RAISE", "MATCH", "TRUTH", "ROADS" };
    private String targetWord;
    private int attempts;
    private JTextField[][] guessFields;
    private JButton checkButton;
    private JTextField inputField;
    private JLabel messageLabel;
    private Set<Character> availableLetters;

    public WordleGame() {
        setTitle("Wordle Game");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        initializeGame();

        JPanel gridPanel = new JPanel(new GridLayout(MAX_ATTEMPTS, WORD_LENGTH));
        guessFields = new JTextField[MAX_ATTEMPTS][WORD_LENGTH];
        for (int i = 0; i < MAX_ATTEMPTS; i++) {
            for (int j = 0; j < WORD_LENGTH; j++) {
                guessFields[i][j] = new JTextField();
                guessFields[i][j].setHorizontalAlignment(JTextField.CENTER);
                guessFields[i][j].setFont(new Font("Arial", Font.PLAIN, 20));
                guessFields[i][j].setEditable(false);
                gridPanel.add(guessFields[i][j]);
            }
        }
        add(gridPanel, BorderLayout.CENTER);

        JPanel inputPanel = new JPanel(new BorderLayout());
        inputField = new JTextField();
        checkButton = new JButton("Check");
        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(checkButton, BorderLayout.EAST);
        add(inputPanel, BorderLayout.SOUTH);

        messageLabel = new JLabel("Enter a 5-letter word", SwingConstants.CENTER);
        add(messageLabel, BorderLayout.NORTH);

        checkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkWord();
            }
        });

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void initializeGame() {
        targetWord = wordList[new Random().nextInt(wordList.length)];
        attempts = 0;
        availableLetters = new HashSet<>();
        for (char c = 'A'; c <= 'Z'; c++) {
            availableLetters.add(c);
        }
        System.out.println("Target word (for debugging): " + targetWord);
    }

    private void checkWord() {
        String guess = inputField.getText().toUpperCase();
        if (guess.length() != WORD_LENGTH) {
            messageLabel.setText("Please enter a 5-letter word");
            return;
        }

        if (attempts >= MAX_ATTEMPTS) {
            messageLabel.setText("No attempts left! The word was: " + targetWord);
            return;
        }

        for (int i = 0; i < WORD_LENGTH; i++) {
            guessFields[attempts][i].setText(String.valueOf(guess.charAt(i)));
            if (guess.charAt(i) == targetWord.charAt(i)) {
                guessFields[attempts][i].setBackground(Color.GREEN);
            } else if (targetWord.contains(String.valueOf(guess.charAt(i)))) {
                guessFields[attempts][i].setBackground(Color.YELLOW);
            } else {
                guessFields[attempts][i].setBackground(Color.GRAY);
            }
            availableLetters.remove(guess.charAt(i));
        }

        attempts++;
        inputField.setText("");

        if (guess.equals(targetWord)) {
            messageLabel.setText("Congratulations! You guessed the word.");
            checkButton.setEnabled(false);
        } else if (attempts >= MAX_ATTEMPTS) {
            messageLabel.setText("No attempts left! The word was: " + targetWord);
            checkButton.setEnabled(false);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new WordleGame().setVisible(true));
    }
}

