package Escritoriojuegos.ajedrez;

class Queen extends Piece {
    public Queen(boolean white) {
        super(white);
    }

    @Override
    public boolean isValidMove(Board board, int startX, int startY, int endX, int endY) {
        Rook rook = new Rook(isWhite());
        Bishop bishop = new Bishop(isWhite());

        if (rook.isValidMove(board, startX, startY, endX, endY) || bishop.isValidMove(board, startX, startY, endX, endY)) {
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return isWhite() ? "Reina Blanca" : "Reina Negra";
    }
}
