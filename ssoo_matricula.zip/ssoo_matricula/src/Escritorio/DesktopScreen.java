package Escritorio;

import Escritoriojuegos.SudokuGame;
import Escritoriojuegos.WordleGame;
import Escritoriojuegos.ajedrez.ChessGame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DesktopScreen {

    private static JFrame desktopFrame;
    private static JLabel backgroundLabel;

    public static void showDesktop() {
        // Crear el frame del escritorio
        desktopFrame = new JFrame("Escritorio");
        desktopFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        desktopFrame.setExtendedState(JFrame.MAXIMIZED_BOTH); // Pantalla completa
        desktopFrame.setLayout(null);

        // Crear el fondo del escritorio
        backgroundLabel = new JLabel();
        backgroundLabel.setOpaque(true);
        backgroundLabel.setLayout(null);
        desktopFrame.setContentPane(backgroundLabel);

        // Añadir la hora y la fecha en la parte superior centrada
        JLabel clockLabel = new JLabel();
        clockLabel.setHorizontalAlignment(SwingConstants.CENTER);
        clockLabel.setVerticalAlignment(SwingConstants.TOP);
        clockLabel.setFont(new Font("Arial", Font.BOLD, 48));
        clockLabel.setForeground(Color.WHITE);
        updateClock(clockLabel);
        int clockWidth = 400;
        int clockHeight = 120;
        clockLabel.setBounds((desktopFrame.getWidth() - clockWidth) / 7, 20, clockWidth, clockHeight);
        backgroundLabel.add(clockLabel);

        // Añadir la barra de búsqueda en la parte inferior centrada
        JTextField searchBar = new JTextField();
        searchBar.setBounds((desktopFrame.getWidth() - 400) / 2, desktopFrame.getHeight() - 60, 400, 30);
        backgroundLabel.add(searchBar);

        // Añadir el icono de Spotify
        int iconSize = 120; // Tamaño de los iconos
        int xOffset = 300;
        int yOffset = 160;
        int margin = 30; // Margen entre los iconos

        JButton spotifyButton = createIconButton("C:\\Users\\raque\\Desktop\\imagenes ssoo\\spotify.jpg", xOffset, yOffset, iconSize, iconSize);
        backgroundLabel.add(spotifyButton);

        // Añadir el icono del Calendario
        JButton calendarButton = createIconButton("C:\\Users\\raque\\Desktop\\imagenes ssoo\\calendario.jpg", xOffset + (iconSize + margin), yOffset, iconSize, iconSize);
        backgroundLabel.add(calendarButton);

        // Añadir el resto de los iconos
        JButton browserButton = createIconButton("C:\\Users\\raque\\Desktop\\imagenes ssoo\\browser_internet_network_6248.jpg", xOffset + 2 * (iconSize + margin), yOffset, iconSize, iconSize);
        JButton fileManagerButton = createIconButton("C:\\Users\\raque\\Desktop\\imagenes ssoo\\Managerfiles_historyfiles_administradordearchivos_6225.jpg", xOffset + 3 * (iconSize + margin), yOffset, iconSize, iconSize);
        JButton settingsButton = createIconButton("C:\\Users\\raque\\Desktop\\imagenes ssoo\\bulb_idea_6103.png", xOffset + 4 * (iconSize + margin), yOffset, iconSize, iconSize);
        JButton pptButton = createIconButton("C:\\Users\\raque\\Desktop\\imagenes ssoo\\ppt.jpg", xOffset, yOffset + iconSize + margin, iconSize, iconSize);
        JButton wordButton = createIconButton("C:\\Users\\raque\\Desktop\\imagenes ssoo\\word.jpg", xOffset + (iconSize + margin), yOffset + iconSize + margin, iconSize, iconSize);
        JButton excelButton = createIconButton("C:\\Users\\raque\\Desktop\\imagenes ssoo\\excel.jpg", xOffset + 2 * (iconSize + margin), yOffset + iconSize + margin, iconSize, iconSize);
        JButton mailButton = createIconButton("C:\\Users\\raque\\Desktop\\imagenes ssoo\\correo.jpg", xOffset + 3 * (iconSize + margin), yOffset + iconSize + margin, iconSize, iconSize);
        JButton aiRecommenderButton = createIconButton("C:\\Users\\raque\\Desktop\\imagenes ssoo\\asistente-de-ai.jpg", xOffset + 4 * (iconSize + margin), yOffset + iconSize + margin, iconSize, iconSize);
        JButton terminalButton = createIconButton("C:\\Users\\raque\\Desktop\\imagenes ssoo\\terminal.jpg", xOffset, yOffset + 2 * (iconSize + margin), iconSize, iconSize);
        JButton gamesFolderButton = createIconButton("C:\\Users\\raque\\Desktop\\imagenes ssoo\\juegos.jpg", xOffset + (iconSize + margin), yOffset + 2 * (iconSize + margin), iconSize, iconSize);

        backgroundLabel.add(browserButton);
        backgroundLabel.add(fileManagerButton);
        backgroundLabel.add(settingsButton);
        backgroundLabel.add(pptButton);
        backgroundLabel.add(wordButton);
        backgroundLabel.add(excelButton);
        backgroundLabel.add(mailButton);
        backgroundLabel.add(aiRecommenderButton);
        backgroundLabel.add(terminalButton);
        backgroundLabel.add(gamesFolderButton);

        // Añadir la barra de estado en la parte inferior
        JPanel statusBar = new JPanel();
        statusBar.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 5));
        statusBar.setBounds(0, desktopFrame.getHeight() - 50, desktopFrame.getWidth(), 50);
        statusBar.setBackground(Color.DARK_GRAY);

        JButton powerButton = new JButton("Power");
        JButton wifiButton = new JButton("WiFi");
        JButton batteryButton = new JButton("Battery");
        JButton volumeButton = new JButton("Volume");

        statusBar.add(powerButton);
        statusBar.add(new JLabel("Notas"));
        statusBar.add(new JLabel("Tiempo"));
        statusBar.add(wifiButton);
        statusBar.add(batteryButton);
        statusBar.add(volumeButton);

        backgroundLabel.add(statusBar);

        // Acción del botón del navegador web
        browserButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openBrowser();
            }
        });

        // Acción del botón del gestor de archivos
        fileManagerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showFileManager();
            }
        });

        // Acción del botón del calendario
        calendarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showCalendar();
            }
        });

        // Acción del botón de ajustes
        settingsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showSettings();
            }
        });

        // Acción del botón de PowerPoint
        pptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openPowerPoint();
            }
        });

        // Acción del botón de Word
        wordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openWord();
            }
        });

        // Acción del botón de Excel
        excelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openExcel();
            }
        });

        // Acción del botón de Correo
        mailButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openMailOptions();
            }
        });

        // Acción del botón de Recomendador de AI
        aiRecommenderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openAIRecommender();
            }
        });

        // Acción del botón de Terminal
        terminalButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openTerminal();
            }
        });

        // Acción del botón de Juegos
        gamesFolderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showGamesFolder();
            }
        });

        // Acción del botón de Spotify
        spotifyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openSpotify();
            }
        });

        // Acción del botón de encendido/apagado
        powerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Cerrar la aplicación
            }
        });

        // Mostrar el escritorio
        desktopFrame.setVisible(true);

        // Ajustar el fondo de pantalla después de mostrar la ventana
        SwingUtilities.invokeLater(() -> setWallpaper("C:\\Users\\raque\\Desktop\\fondos de pantalla\\106826.jpg"));

        // Actualizar el reloj cada segundo
        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateClock(clockLabel);
            }
        });
        timer.start();
    }

    private static JButton createIconButton(String imagePath, int x, int y, int width, int height) {
        JButton button = new JButton(new ImageIcon(new ImageIcon(imagePath).getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH)));
        button.setBounds(x, y, width, height);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        return button;
    }

    private static void updateClock(JLabel clockLabel) {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String timeText = now.format(timeFormatter);
        String dateText = now.format(dateFormatter);
        clockLabel.setText("<html>" + timeText + "<br>" + dateText + "</html>");
    }

    private static void setWallpaper(String imagePath) {
        ImageIcon icon = new ImageIcon(imagePath);
        Image image = icon.getImage();
        int width = desktopFrame.getWidth();
        int height = desktopFrame.getHeight();
        if (width > 0 && height > 0) {
            Image scaledImage = image.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            icon = new ImageIcon(scaledImage);
            backgroundLabel.setIcon(icon);
        } else {
            System.err.println("Error: La ventana tiene dimensiones no válidas para el fondo de pantalla.");
        }
    }

    private static void showFileManager() {
        JFrame fileManagerFrame = new JFrame("Gestor de Archivos");
        fileManagerFrame.setSize(800, 600);
        fileManagerFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        fileChooser.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (JFileChooser.APPROVE_SELECTION.equals(e.getActionCommand())) {
                    File selectedFile = fileChooser.getSelectedFile();
                    if (selectedFile.isFile()) {
                        try {
                            Desktop.getDesktop().open(selectedFile);
                        } catch (IOException ex) {
                            JOptionPane.showMessageDialog(null, "No se puede abrir el archivo: " + ex.getMessage());
                        }
                    } else if (selectedFile.isDirectory()) {
                        showDirectoryContents(selectedFile);
                    }
                }
            }
        });

        fileManagerFrame.add(fileChooser, BorderLayout.CENTER);
        fileManagerFrame.setVisible(true);
    }

    private static void showDirectoryContents(File directory) {
        JFrame directoryFrame = new JFrame("Contenido de " + directory.getName());
        directoryFrame.setSize(800, 600);
        directoryFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JList<String> fileList = new JList<>(directory.list());
        JScrollPane scrollPane = new JScrollPane(fileList);
        directoryFrame.add(scrollPane, BorderLayout.CENTER);

        directoryFrame.setVisible(true);
    }

    private static void showCalendar() {
        JFrame calendarFrame = new JFrame("Calendario");
        calendarFrame.setSize(800, 600);
        calendarFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        CalendarPanel calendarPanel = new CalendarPanel();
        calendarFrame.add(calendarPanel);

        JPanel calendarControlPanel = new JPanel();
        calendarControlPanel.setLayout(new FlowLayout());

        JButton addEventButton = new JButton("Añadir Evento");
        String[] views = {"Weekly", "Monthly", "Yearly"};
        JComboBox<String> viewComboBox = new JComboBox<>(views);
        JButton prevButton = new JButton("<");
        JButton nextButton = new JButton(">");

        calendarControlPanel.add(addEventButton);
        calendarControlPanel.add(viewComboBox);
        calendarControlPanel.add(prevButton);
        calendarControlPanel.add(nextButton);

        calendarFrame.add(calendarControlPanel, BorderLayout.NORTH);

        addEventButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EventDialog eventDialog = new EventDialog(calendarFrame);
                eventDialog.setVisible(true);

                if (eventDialog.isConfirmed()) {
                    calendarPanel.addEvent(eventDialog.getDay(), eventDialog.getStartHour(), eventDialog.getEndHour(),
                            eventDialog.getEventName(), eventDialog.getColor());
                }
            }
        });

        viewComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedView = (String) viewComboBox.getSelectedItem();
                calendarPanel.setView(selectedView);
            }
        });

        prevButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calendarPanel.previous();
            }
        });

        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calendarPanel.next();
            }
        });

        calendarFrame.setVisible(true);
    }

    private static void showSettings() {
        JFrame settingsFrame = new JFrame("Ajustes");
        settingsFrame.setSize(800, 600);
        settingsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JTabbedPane tabbedPane = new JTabbedPane();

        tabbedPane.addTab("General", new GeneralSettingsPanel());
        tabbedPane.addTab("Display", new DisplaySettingsPanel());
        tabbedPane.addTab("Mouse", new MouseSettingsPanel());

        settingsFrame.add(tabbedPane, BorderLayout.CENTER);
        settingsFrame.setVisible(true);
    }

    // Paneles de Ajustes
    static class GeneralSettingsPanel extends JPanel {
        public GeneralSettingsPanel() {
            setLayout(new BorderLayout());
            JLabel label = new JLabel("Configuraciones Generales", SwingConstants.CENTER);
            add(label, BorderLayout.CENTER);
        }
    }

    static class DisplaySettingsPanel extends JPanel {
        public DisplaySettingsPanel() {
            setLayout(new GridLayout(3, 1));
            add(new JLabel("Configuración de la pantalla"));

            JButton changeWallpaperButton = new JButton("Cambiar Fondo de Pantalla");
            changeWallpaperButton.addActionListener(e -> changeWallpaper());
            add(changeWallpaperButton);
        }

        private void changeWallpaper() {
            JFileChooser fileChooser = new JFileChooser();
            int option = fileChooser.showOpenDialog(this);
            if (option == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                setWallpaper(file.getAbsolutePath());
            }
        }

        private void setWallpaper(String imagePath) {
            ImageIcon icon = new ImageIcon(imagePath);
            Image image = icon.getImage();
            int width = desktopFrame.getWidth();
            int height = desktopFrame.getHeight();
            if (width > 0 && height > 0) {
                Image scaledImage = image.getScaledInstance(width, height, Image.SCALE_SMOOTH);
                icon = new ImageIcon(scaledImage);
                backgroundLabel.setIcon(icon);
            } else {
                System.err.println("Error: La ventana tiene dimensiones no válidas para el fondo de pantalla.");
            }
        }
    }

    static class MouseSettingsPanel extends JPanel {
        public MouseSettingsPanel() {
            setLayout(new GridLayout(3, 1));
            add(new JLabel("Configuración del ratón"));

            JSlider speedSlider = new JSlider(1, 10, 5);
            speedSlider.setPaintTicks(true);
            speedSlider.setPaintLabels(true);
            speedSlider.setMajorTickSpacing(1);
            speedSlider.addChangeListener(e -> changeMouseSpeed(speedSlider.getValue()));
            add(speedSlider);
        }

        private void changeMouseSpeed(int speed) {
            JOptionPane.showMessageDialog(this, "Velocidad del ratón cambiada a: " + speed);
        }
    }

    private static void openWord() {
        try {
            // Comando para abrir Microsoft Word en Windows
            String command = "cmd /c start winword";
            Runtime.getRuntime().exec(command);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(desktopFrame, "No se pudo abrir Microsoft Word.");
        }
    }

    private static void openPowerPoint() {
        try {
            // Comando para abrir Microsoft PowerPoint en Windows
            String command = "cmd /c start powerpnt";
            Runtime.getRuntime().exec(command);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(desktopFrame, "No se pudo abrir Microsoft PowerPoint.");
        }
    }

    private static void openExcel() {
        try {
            // Comando para abrir Microsoft Excel en Windows
            String command = "cmd /c start excel";
            Runtime.getRuntime().exec(command);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(desktopFrame, "No se pudo abrir Microsoft Excel.");
        }
    }

    private static void openBrowser() {
        try {
            // Comando para abrir Google Chrome en Windows
            String url = "https://www.google.com";
            String command = "cmd /c start chrome " + url;
            Runtime.getRuntime().exec(command);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(desktopFrame, "No se pudo abrir Google Chrome.");
        }
    }

    private static void openMailOptions() {
        Object[] options = {"Gmail", "Outlook"};
        int choice = JOptionPane.showOptionDialog(desktopFrame, "Elige tu servicio de correo", "Correo",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        if (choice == 0) {
            openGmail();
        } else if (choice == 1) {
            openOutlook();
        }
    }

    private static void openGmail() {
        try {
            // Comando para abrir Gmail en Google Chrome
            String url = "https://mail.google.com";
            String command = "cmd /c start chrome " + url;
            Runtime.getRuntime().exec(command);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(desktopFrame, "No se pudo abrir Gmail.");
        }
    }

    private static void openOutlook() {
        try {
            // Comando para abrir la aplicación de Outlook en Windows
            String command = "cmd /c start outlook";
            Runtime.getRuntime().exec(command);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(desktopFrame, "No se pudo abrir la aplicación de Outlook.");
        }
    }

    private static void openAIRecommender() {
        JFrame aiRecommenderFrame = new JFrame("Recomendador de Inteligencias Artificiales");
        aiRecommenderFrame.setSize(600, 400);
        aiRecommenderFrame.setLayout(new BorderLayout());

        JLabel questionLabel = new JLabel("¿Qué tipo de inteligencia artificial necesitas?");
        questionLabel.setHorizontalAlignment(SwingConstants.CENTER);
        questionLabel.setFont(new Font("Arial", Font.BOLD, 16));
        aiRecommenderFrame.add(questionLabel, BorderLayout.NORTH);

        String[] options = {
                "Lalal.ai: Separación musical y eliminación de voces. Facilita la extracción de elementos de audio de cualquier archivo, siendo una herramienta útil para proyectos musicales.",
                "Canva: Diseñada para transformar la creatividad en una tarea sencilla y accesible. Permite convertir textos en imágenes, creando así obras únicas con variados estilos artísticos.",
                "TensorFlow: Se especializa en computación numérica y aprendizaje automático a gran escala.",
                "Grammarly: Asistente de escritura online que revisa gramática, ortografía, puntuación y plagio.",
                "Fireflies: Especialmente creada para grabar y transcribir conversaciones, útil para conversaciones en tiempo real.",
                "DALL-E: Capacidad de generar imágenes a partir de descripciones textuales.",
                "ChatGPT: Inteligencia artificial para crear contenido y redactar textos.",
                "Blackbox AI: ayuda a la comprensión de lenguajes de programación."
        };
        JComboBox<String> aiComboBox = new JComboBox<>(options);
        aiComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        aiRecommenderFrame.add(aiComboBox, BorderLayout.CENTER);

        JButton recommendButton = new JButton("Recomendar");
        recommendButton.setFont(new Font("Arial", Font.BOLD, 14));
        aiRecommenderFrame.add(recommendButton, BorderLayout.SOUTH);

        recommendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedAI = (String) aiComboBox.getSelectedItem();
                openSelectedAI(selectedAI.split(":")[0]);
            }
        });

        aiRecommenderFrame.setVisible(true);
    }

    private static void openSelectedAI(String aiName) {
        String url = "";
        switch (aiName) {
            case "Lalal.ai":
                url = "https://www.lalal.ai/";
                break;
            case "Canva":
                url = "https://www.canva.com/";
                break;
            case "TensorFlow":
                url = "https://www.tensorflow.org/";
                break;
            case "Grammarly":
                url = "https://www.grammarly.com/";
                break;
            case "Fireflies":
                url = "https://fireflies.ai/";
                break;
            case "DALL-E":
                url = "https://www.openai.com/dall-e-2/";
                break;
            case "ChatGPT":
                url = "https://chat.openai.com/";
                break;
            case "Blackbox AI":
                url = "https://www.blackbox.cool/";
                break;
            default:
                JOptionPane.showMessageDialog(desktopFrame, "Opción no válida.");
                return;
        }
        try {
            String command = "cmd /c start chrome " + url;
            Runtime.getRuntime().exec(command);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(desktopFrame, "No se pudo abrir " + aiName);
        }
    }

    private static void openTerminal() {
        SwingUtilities.invokeLater(() -> new CustomTerminal().setVisible(true));
    }

    private static void showGamesFolder() {
        JFrame gamesFrame = new JFrame("Juegos");
        gamesFrame.setSize(400, 300);
        gamesFrame.setLayout(new GridLayout(3, 1));
        gamesFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JButton sudokuButton = createGameButton("Sudoku");
        JButton chessButton = createGameButton("Ajedrez");
        JButton wordleButton = createGameButton("Wordle");

        gamesFrame.add(sudokuButton);
        gamesFrame.add(chessButton);
        gamesFrame.add(wordleButton);

        sudokuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(() -> new SudokuGame().setVisible(true));
            }
        });

        chessButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(() -> new ChessGame().setVisible(true));
            }
        });

        wordleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(() -> new WordleGame().setVisible(true));
            }
        });

        gamesFrame.setLocationRelativeTo(null);
        gamesFrame.setVisible(true);
    }

    private static JButton createGameButton(String text) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(150, 50));
        return button;
    }

    private static void openSpotify() {
        try {
            // Comando para abrir Spotify en Windows
            String command = "cmd /c start spotify";
            Runtime.getRuntime().exec(command);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(desktopFrame, "No se pudo abrir Spotify.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> showDesktop());
    }
}

