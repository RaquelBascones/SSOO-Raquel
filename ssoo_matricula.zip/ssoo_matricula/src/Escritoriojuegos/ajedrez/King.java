package Escritoriojuegos.ajedrez;

class King extends Piece {
    public King(boolean white) {
        super(white);
    }

    @Override
    public boolean isValidMove(Board board, int startX, int startY, int endX, int endY) {
        int dx = Math.abs(startX - endX);
        int dy = Math.abs(startY - endY);
        return dx <= 1 && dy <= 1; // King moves one square in any direction
    }

    @Override
    public String toString() {
        return isWhite() ? "Rey Blanco" : "Rey Negro";
    }
}
