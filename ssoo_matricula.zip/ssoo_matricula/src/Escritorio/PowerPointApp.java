package Escritorio;

import javax.swing.*;
import java.awt.*;

public class PowerPointApp {

    public static void showPowerPoint() {
        JFrame pptFrame = new JFrame("PowerPoint");
        pptFrame.setSize(800, 600);
        pptFrame.setLayout(new BorderLayout());

        JTextArea pptArea = new JTextArea();
        pptArea.setText("Aquí puedes crear tus presentaciones estilo PowerPoint.");

        pptFrame.add(new JScrollPane(pptArea), BorderLayout.CENTER);

        pptFrame.setVisible(true);
    }
}
