package Escritoriojuegos.ajedrez;

class Knight extends Piece {
    public Knight(boolean white) {
        super(white);
    }

    @Override
    public boolean isValidMove(Board board, int startX, int startY, int endX, int endY) {
        int dx = Math.abs(startX - endX);
        int dy = Math.abs(startY - endY);
        return dx * dy == 2; // L-shaped move
    }

    @Override
    public String toString() {
        return isWhite() ? "Caballo Blanco" : "Caballo Negro";
    }
}
