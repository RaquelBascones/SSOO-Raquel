package Escritoriojuegos.ajedrez;

class Pawn extends Piece {
    public Pawn(boolean white) {
        super(white);
    }

    @Override
    public boolean isValidMove(Board board, int startX, int startY, int endX, int endY) {
        int direction = isWhite() ? -1 : 1;
        if (startY == endY && startX + direction == endX && board.getPieceAt(endX, endY) == null) {
            return true;
        }
        // Capture move
        if (Math.abs(startY - endY) == 1 && startX + direction == endX && board.getPieceAt(endX, endY) != null && board.getPieceAt(endX, endY).isWhite() != isWhite()) {
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return isWhite() ? "Peón Blanco" : "Peón Negro";
    }
}
