package Escritoriojuegos.ajedrez;

class Bishop extends Piece {
    public Bishop(boolean white) {
        super(white);
    }

    @Override
    public boolean isValidMove(Board board, int startX, int startY, int endX, int endY) {
        if (isDiagonalMove(startX, startY, endX, endY)) {
            if (!isPathBlocked(board, startX, startY, endX, endY)) {
                return true;
            }
        }
        return false;
    }

    private boolean isPathBlocked(Board board, int startX, int startY, int endX, int endY) {
        int xStep = (startX < endX) ? 1 : -1;
        int yStep = (startY < endY) ? 1 : -1;
        int x = startX + xStep;
        int y = startY + yStep;
        while (x != endX && y != endY) {
            if (board.getPieceAt(x, y) != null) {
                return true;
            }
            x += xStep;
            y += yStep;
        }
        return false;
    }

    @Override
    public String toString() {
        return isWhite() ? "Alfil Blanco" : "Alfil Negro";
    }
}
