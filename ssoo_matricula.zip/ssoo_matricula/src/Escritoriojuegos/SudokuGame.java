package Escritoriojuegos;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class SudokuGame extends JFrame {
    private static final int SIZE = 9;
    private JTextField[][] cells = new JTextField[SIZE][SIZE];
    private int[][] board;
    private int[][] solution;

    public SudokuGame() {
        setTitle("Sudoku Game");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cambiado a DISPOSE_ON_CLOSE
        setLayout(new BorderLayout());

        JPanel gridPanel = new JPanel(new GridLayout(SIZE, SIZE));
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                cells[i][j] = new JTextField();
                cells[i][j].setHorizontalAlignment(JTextField.CENTER);
                cells[i][j].setFont(new Font("Arial", Font.PLAIN, 20));
                gridPanel.add(cells[i][j]);
            }
        }
        add(gridPanel, BorderLayout.CENTER);

        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Options");
        JMenuItem checkItem = new JMenuItem("Check");
        JMenuItem clearItem = new JMenuItem("Clear");
        JMenuItem newGameItem = new JMenuItem("New Game");

        checkItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                checkSudoku();
            }
        });

        clearItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clearBoard();
            }
        });

        newGameItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                selectDifficulty();
            }
        });

        menu.add(checkItem);
        menu.add(clearItem);
        menu.add(newGameItem);
        menuBar.add(menu);
        setJMenuBar(menuBar);

        selectDifficulty();
    }

    private void initializeBoard() {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                cells[i][j].setText("");
                cells[i][j].setEditable(true);
                cells[i][j].setForeground(Color.BLACK);
                cells[i][j].setBackground(Color.WHITE);
            }
        }
    }

    private void generateSudoku(int difficulty) {
        board = new int[SIZE][SIZE];
        solution = new int[SIZE][SIZE];

        fillDiagonalSubgrids();
        fillRemaining(0, 3);

        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                solution[i][j] = board[i][j];
                cells[i][j].setText("");
                cells[i][j].setEditable(true);
                cells[i][j].setForeground(Color.BLACK);
                cells[i][j].setBackground(Color.WHITE);
            }
        }

        removeCells(difficulty);
    }

    private void fillDiagonalSubgrids() {
        for (int i = 0; i < SIZE; i += 3) {
            fillSubgrid(i, i);
        }
    }

    private void fillSubgrid(int row, int col) {
        Random rand = new Random();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                int num;
                do {
                    num = rand.nextInt(9) + 1;
                } while (!isSafeToPlace(row + i, col + j, num));
                board[row + i][col + j] = num;
            }
        }
    }

    private boolean fillRemaining(int i, int j) {
        if (j >= SIZE && i < SIZE - 1) {
            i++;
            j = 0;
        }
        if (i >= SIZE && j >= SIZE) {
            return true;
        }
        if (i < 3) {
            if (j < 3) {
                j = 3;
            }
        } else if (i < SIZE - 3) {
            if (j == (i / 3) * 3) {
                j += 3;
            }
        } else {
            if (j == SIZE - 3) {
                i++;
                j = 0;
                if (i >= SIZE) {
                    return true;
                }
            }
        }

        for (int num = 1; num <= SIZE; num++) {
            if (isSafeToPlace(i, j, num)) {
                board[i][j] = num;
                if (fillRemaining(i, j + 1)) {
                    return true;
                }
                board[i][j] = 0;
            }
        }
        return false;
    }

    private boolean isSafeToPlace(int i, int j, int num) {
        return !usedInRow(i, num) && !usedInCol(j, num) && !usedInSubgrid(i - i % 3, j - j % 3, num);
    }

    private boolean usedInRow(int i, int num) {
        for (int j = 0; j < SIZE; j++) {
            if (board[i][j] == num) {
                return true;
            }
        }
        return false;
    }

    private boolean usedInCol(int j, int num) {
        for (int i = 0; i < SIZE; i++) {
            if (board[i][j] == num) {
                return true;
            }
        }
        return false;
    }

    private boolean usedInSubgrid(int row, int col, int num) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[row + i][col + j] == num) {
                    return true;
                }
            }
        }
        return false;
    }

    private void removeCells(int difficulty) {
        int cellsToRemove = difficulty * 10 + 20; // Easy: 30, Medium: 40, Hard: 50
        Random rand = new Random();
        while (cellsToRemove > 0) {
            int i = rand.nextInt(SIZE);
            int j = rand.nextInt(SIZE);
            if (board[i][j] != 0) {
                board[i][j] = 0;
                cellsToRemove--;
            }
        }

        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (board[i][j] != 0) {
                    cells[i][j].setText(String.valueOf(board[i][j]));
                    cells[i][j].setEditable(false);
                    cells[i][j].setBackground(Color.LIGHT_GRAY);
                } else {
                    cells[i][j].setText("");
                    cells[i][j].setEditable(true);
                }
            }
        }
    }

    private void checkSudoku() {
        boolean isCorrect = true;
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (cells[i][j].isEditable()) {
                    String text = cells[i][j].getText();
                    if (!text.isEmpty()) {
                        int value = Integer.parseInt(text);
                        if (value != solution[i][j]) {
                            cells[i][j].setForeground(Color.RED);
                            isCorrect = false;
                        } else {
                            cells[i][j].setForeground(Color.BLACK);
                        }
                    }
                }
            }
        }
        if (isCorrect) {
            JOptionPane.showMessageDialog(this, "Congratulations! You solved the Sudoku correctly.");
        }
    }

    private void clearBoard() {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (cells[i][j].isEditable()) {
                    cells[i][j].setText("");
                    cells[i][j].setForeground(Color.BLACK);
                }
            }
        }
    }

    private void selectDifficulty() {
        String[] options = {"Easy", "Medium", "Hard"};
        int choice = JOptionPane.showOptionDialog(this, "Select Difficulty", "New Game",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
        if (choice != JOptionPane.CLOSED_OPTION) {
            int difficulty = choice + 1; // Easy: 1, Medium: 2, Hard: 3
            generateSudoku(difficulty);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new SudokuGame().setVisible(true);
            }
        });
    }
}
