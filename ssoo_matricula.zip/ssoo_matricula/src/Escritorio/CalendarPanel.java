package Escritorio;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

public class CalendarPanel extends JPanel {
    private JPanel innerPanel;
    private JScrollPane scrollPane;
    private List<Event> events;
    private String currentView = "Weekly"; // Default view
    private LocalDate currentDate;

    public CalendarPanel() {
        events = new ArrayList<>();
        setLayout(new BorderLayout());
        innerPanel = new JPanel();
        innerPanel.setBackground(Color.BLACK);
        innerPanel.setLayout(new GridBagLayout());

        currentDate = LocalDate.now();

        scrollPane = new JScrollPane(innerPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        add(scrollPane, BorderLayout.CENTER);
        updateView();
    }

    public void addEvent(String day, int startHour, int endHour, String eventName, Color color) {
        events.add(new Event(day, startHour, endHour, eventName, color));
        updateView();
    }

    public void setView(String view) {
        currentView = view;
        updateView();
    }

    public void next() {
        if (currentView.equals("Weekly")) {
            currentDate = currentDate.plusWeeks(1);
        } else if (currentView.equals("Monthly")) {
            currentDate = currentDate.plusMonths(1);
        } else if (currentView.equals("Yearly")) {
            currentDate = currentDate.plusYears(1);
        }
        updateView();
    }

    public void previous() {
        if (currentView.equals("Weekly")) {
            currentDate = currentDate.minusWeeks(1);
        } else if (currentView.equals("Monthly")) {
            currentDate = currentDate.minusMonths(1);
        } else if (currentView.equals("Yearly")) {
            currentDate = currentDate.minusYears(1);
        }
        updateView();
    }

    private void updateView() {
        innerPanel.removeAll();

        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.weighty = 1.0;

        if (currentView.equals("Weekly")) {
            updateWeeklyView(c);
        } else if (currentView.equals("Monthly")) {
            updateMonthlyView(c);
        } else if (currentView.equals("Yearly")) {
            updateYearlyView(c);
        }

        innerPanel.revalidate();
        innerPanel.repaint();
    }

    private void updateWeeklyView(GridBagConstraints c) {
        String[] days = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
        LocalDate startOfWeek = currentDate.with(DayOfWeek.MONDAY);

        for (int i = 0; i < days.length; i++) {
            c.gridx = i;
            c.gridy = 0;
            JLabel dayLabel = new JLabel(days[i], SwingConstants.CENTER);
            dayLabel.setForeground(Color.WHITE);
            innerPanel.add(dayLabel, c);
        }

        for (int i = 0; i < 24; i++) {
            c.gridx = 0;
            c.gridy = i + 1;
            JLabel timeLabel = new JLabel(String.format("%02d:00", i), SwingConstants.CENTER);
            timeLabel.setForeground(Color.WHITE);
            innerPanel.add(timeLabel, c);
        }

        for (Event event : events) {
            int dayIndex = getDayIndex(event.day);
            if (dayIndex == -1) continue;

            c.gridx = dayIndex;
            c.gridy = event.startHour + 1;
            c.gridheight = event.endHour - event.startHour;
            EventPanel eventPanel = new EventPanel(event.eventName, event.color);
            innerPanel.add(eventPanel, c);
        }
    }

    private void updateMonthlyView(GridBagConstraints c) {
        YearMonth yearMonth = YearMonth.from(currentDate);
        int daysInMonth = yearMonth.lengthOfMonth();
        LocalDate firstOfMonth = yearMonth.atDay(1);
        int dayOfWeekValue = firstOfMonth.getDayOfWeek().getValue();
        dayOfWeekValue = (dayOfWeekValue + 6) % 7; // Adjust for Monday as the first day

        JLabel monthLabel = new JLabel(yearMonth.getMonth().toString() + " " + yearMonth.getYear(), SwingConstants.CENTER);
        monthLabel.setForeground(Color.WHITE);
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 7;
        innerPanel.add(monthLabel, c);

        c.gridwidth = 1;
        c.insets = new Insets(1, 1, 1, 1);
        
        String[] daysOfWeek = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
        
        for (int i = 0; i < daysOfWeek.length; i++) {
            c.gridx = i;
            c.gridy = 1;
            JLabel dayLabel = new JLabel(daysOfWeek[i], SwingConstants.CENTER);
            dayLabel.setForeground(Color.WHITE);
            innerPanel.add(dayLabel, c);
        }

        for (int i = 1; i <= daysInMonth; i++) {
            c.gridx = (dayOfWeekValue + i - 1) % 7;
            c.gridy = 2 + (dayOfWeekValue + i - 1) / 7;
            JLabel dayLabel = new JLabel(String.valueOf(i), SwingConstants.CENTER);
            dayLabel.setForeground(Color.WHITE);
            dayLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY)); // Adding borders for better separation
            innerPanel.add(dayLabel, c);
        }
    }

    private void updateYearlyView(GridBagConstraints c) {
        String[] months = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};
        String[] daysOfWeek = {"L", "M", "X", "J", "V", "S", "D"};
        
        c.insets = new Insets(5, 5, 5, 5);

        JLabel yearLabel = new JLabel(String.valueOf(currentDate.getYear()), SwingConstants.CENTER);
        yearLabel.setForeground(Color.WHITE);
        yearLabel.setFont(new Font("Arial", Font.BOLD, 24));
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 3;
        innerPanel.add(yearLabel, c);

        c.gridwidth = 1;
        
        for (int i = 0; i < months.length; i++) {
            JPanel monthPanel = new JPanel(new GridLayout(8, 7));
            TitledBorder border = BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.WHITE), months[i]);
            border.setTitleColor(Color.WHITE);
            monthPanel.setBorder(border);
            monthPanel.setBackground(Color.BLACK);

            for (String day : daysOfWeek) {
                JLabel dayLabel = new JLabel(day, SwingConstants.CENTER);
                dayLabel.setForeground(Color.WHITE);
                monthPanel.add(dayLabel);
            }

            YearMonth yearMonth = YearMonth.of(currentDate.getYear(), i + 1);
            int daysInMonth = yearMonth.lengthOfMonth();
            LocalDate firstOfMonth = yearMonth.atDay(1);
            int dayOfWeekValue = (firstOfMonth.getDayOfWeek().getValue() % 7) - 1; // Adjust for Monday as the first day

            if(dayOfWeekValue == -1) dayOfWeekValue = 6; // Correcting for Sunday

            for (int j = 0; j < dayOfWeekValue; j++) {
                monthPanel.add(new JLabel("")); // Empty labels for padding
            }

            for (int day = 1; day <= daysInMonth; day++) {
                JLabel dayLabel = new JLabel(String.valueOf(day), SwingConstants.CENTER);
                dayLabel.setForeground(Color.WHITE);
                monthPanel.add(dayLabel);
            }

            c.gridx = i % 3;
            c.gridy = (i / 3) + 1;
            innerPanel.add(monthPanel, c);
        }
    }

    private int getDayIndex(String day) {
        switch (day.toLowerCase()) {
            case "sunday": return 6;
            case "monday": return 0;
            case "tuesday": return 1;
            case "wednesday": return 2;
            case "thursday": return 3;
            case "friday": return 4;
            case "saturday": return 5;
            default: return -1;
        }
    }

    private static class EventPanel extends JPanel {
        public EventPanel(String eventName, Color color) {
            this.setBackground(color);
            this.setBorder(BorderFactory.createLineBorder(Color.WHITE));
            JLabel label = new JLabel(eventName, SwingConstants.CENTER);
            label.setForeground(Color.WHITE);
            this.add(label);
        }
    }

    private static class Event {
        String day;
        int startHour;
        int endHour;
        String eventName;
        Color color;

        public Event(String day, int startHour, int endHour, String eventName, Color color) {
            this.day = day;
            this.startHour = startHour;
            this.endHour = endHour;
            this.eventName = eventName;
            this.color = color;
        }
    }
}



