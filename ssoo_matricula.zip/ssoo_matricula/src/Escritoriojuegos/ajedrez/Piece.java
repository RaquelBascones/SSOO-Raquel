package Escritoriojuegos.ajedrez;

abstract class Piece {
    private boolean white;

    public Piece(boolean white) {
        this.white = white;
    }

    public boolean isWhite() {
        return white;
    }

    public abstract boolean isValidMove(Board board, int startX, int startY, int endX, int endY);

    protected boolean isStraightMove(int startX, int startY, int endX, int endY) {
        return startX == endX || startY == endY;
    }

    protected boolean isDiagonalMove(int startX, int startY, int endX, int endY) {
        return Math.abs(startX - endX) == Math.abs(startY - endY);
    }

    @Override
    public abstract String toString();
}
