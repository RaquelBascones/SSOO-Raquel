package Escritorio;

import javax.swing.*;
import java.awt.*;

public class ExcelApp {

    public static void showExcel() {
        JFrame excelFrame = new JFrame("Excel");
        excelFrame.setSize(800, 600);
        excelFrame.setLayout(new BorderLayout());

        JTable table = new JTable(10, 5);
        JScrollPane scrollPane = new JScrollPane(table);
        excelFrame.add(scrollPane, BorderLayout.CENTER);

        excelFrame.setVisible(true);
    }
}

