package Escritoriojuegos.ajedrez;

class Rook extends Piece {
    public Rook(boolean white) {
        super(white);
    }

    @Override
    public boolean isValidMove(Board board, int startX, int startY, int endX, int endY) {
        if (isStraightMove(startX, startY, endX, endY)) {
            if (!isPathBlocked(board, startX, startY, endX, endY)) {
                return true;
            }
        }
        return false;
    }

    protected boolean isPathBlocked(Board board, int startX, int startY, int endX, int endY) {
        if (startX == endX) {
            int step = (startY < endY) ? 1 : -1;
            for (int i = startY + step; i != endY; i += step) {
                if (board.getPieceAt(startX, i) != null) {
                    return true;
                }
            }
        } else if (startY == endY) {
            int step = (startX < endX) ? 1 : -1;
            for (int i = startX + step; i != endX; i += step) {
                if (board.getPieceAt(i, startY) != null) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return isWhite() ? "Torre Blanca" : "Torre Negra";
    }
}
