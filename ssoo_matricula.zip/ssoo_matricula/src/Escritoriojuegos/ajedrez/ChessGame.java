package Escritoriojuegos.ajedrez;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChessGame extends JFrame {
    private static final int BOARD_SIZE = 8;
    private JButton[][] squares = new JButton[BOARD_SIZE][BOARD_SIZE];
    private Board board;
    private Point selectedSquare;
    private boolean isWhiteTurn = true;

    public ChessGame() {
        setTitle("Juego de Ajedrez");
        setSize(800, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        board = new Board();
        JPanel boardPanel = new JPanel(new GridLayout(BOARD_SIZE, BOARD_SIZE));
        initializeBoard(boardPanel);
        add(boardPanel, BorderLayout.CENTER);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void initializeBoard(JPanel boardPanel) {
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                final int currentRow = row;
                final int currentCol = col;
                JButton button = new JButton();
                button.setPreferredSize(new Dimension(75, 75));
                button.setBackground((row + col) % 2 == 0 ? Color.WHITE : Color.GRAY);
                button.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        handleSquareClick(button, currentRow, currentCol);
                    }
                });
                squares[row][col] = button;
                boardPanel.add(button);
            }
        }
        updateBoard();
    }

    private void updateBoard() {
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                Piece piece = board.getPieceAt(row, col);
                squares[row][col].setText(piece != null ? piece.toString() : "");
            }
        }
    }

    private void handleSquareClick(JButton button, int row, int col) {
        if (selectedSquare == null) {
            if (board.getPieceAt(row, col) != null && board.getPieceAt(row, col).isWhite() == isWhiteTurn) {
                selectedSquare = new Point(row, col);
                button.setBackground(Color.YELLOW);
            }
        } else {
            if (board.movePiece(selectedSquare.x, selectedSquare.y, row, col)) {
                isWhiteTurn = !isWhiteTurn;
            }
            resetSquareColors();
            selectedSquare = null;
            updateBoard();
        }
    }

    private void resetSquareColors() {
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                squares[row][col].setBackground((row + col) % 2 == 0 ? Color.WHITE : Color.GRAY);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ChessGame());
    }
}

